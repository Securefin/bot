from telethon import TelegramClient, events, Button
from datetime import datetime
import asyncio
import os
from flask import Flask, jsonify
from threading import Thread
import logging
import time
import psutil
from collections import defaultdict

# Initialize start time and counters
start_time = time.time()
user_mentions_count = defaultdict(int)
total_mentions = 0

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Environment variables
api_id = int(os.environ['API_ID'])
api_hash = os.environ['API_HASH']
your_username = os.environ['USERNAME']  # Without @
group_chat_id = int(os.environ['GROUP_ID'])
admin_user_id = int(os.environ.get('ADMIN_ID', 0))  # Optional admin ID

client = TelegramClient('session', api_id, api_hash)

# Flask server setup
app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({
        "status": "alive",
        "service": "Telegram Mention Bot",
        "total_mentions": total_mentions,
        "timestamp": datetime.now().isoformat()
    })

@app.route('/health')
def health_check():
    try:
        telegram_status = {
            "connected": False,
            "error": None,
            "last_mention": None
        }

        try:
            if client.is_connected():
                client.loop.run_until_complete(client.get_me())
                telegram_status["connected"] = True

                # Try to read last mention from log
                try:
                    with open("mentions_log.txt", "r", encoding="utf-8") as f:
                        last_line = f.readlines()[-1] if f.readlines() else None
                        telegram_status["last_mention"] = last_line[:100] + "..." if last_line else None
                except:
                    pass
        except Exception as e:
            telegram_status["error"] = str(e)

        return jsonify({
            "status": "healthy" if telegram_status["connected"] else "degraded",
            "telegram_connected": telegram_status["connected"],
            "last_mention": telegram_status["last_mention"],
            "system": {
                "memory_usage_mb": round(psutil.Process().memory_info().rss / 1024 / 1024, 2),
                "cpu_usage_percent": psutil.cpu_percent(),
                "uptime_seconds": round(time.time() - start_time, 2)
            },
            "timestamp": datetime.now().isoformat()
        }), 200 if telegram_status["connected"] else 503

    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }), 500

def run_flask():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run_flask)
    t.daemon = True
    t.start()

# Improved mention handler with buttons and analytics
@client.on(events.NewMessage)
async def handler(event):
    global total_mentions
    try:
        if event.message.mentioned and f"@{your_username}" in event.raw_text:
            total_mentions += 1
            sender = await event.get_sender()
            chat = await event.get_chat()
            message = event.message
            mention_time = datetime.now()

            # Update user mention count
            user_mentions_count[sender.id] += 1

            # Generate message link (for supergroups/channels)
            if hasattr(chat, 'username'):
                message_link = f"https://t.me/c/{chat.id}/{message.id}"
            else:
                message_link = "N/A"

            # Prepare the alert message
            alert_message = (
                f"🔔 **New Mention** (#{total_mentions})\n\n"
                f"👤 **From:** {sender.first_name or 'Unknown'}"
                f"{f' (@{sender.username})' if hasattr(sender, 'username') else ''}\n"
                f"🆔 User ID: `{sender.id}` • Mentions: {user_mentions_count[sender.id]}\n\n"
                f"💬 **In:** {getattr(chat, 'title', 'Private Chat')}\n"
                f"🆔 Chat ID: `{chat.id}`\n\n"
                f"✉️ **Message:**\n```\n{event.raw_text[:1000]}\n```\n\n"
                f"⏰ **Time:** {mention_time.strftime('%H:%M:%S')}\n"
                f"📅 **Date:** {mention_time.strftime('%d %b %Y')}"
            )

            # Create buttons
            buttons = []
            if message_link != "N/A":
                buttons.append([Button.url('🔗 Go to Message', message_link)])
            if sender.id == admin_user_id:
                buttons.append([Button.inline('📊 Get Stats', b'get_stats')])

            # Send the alert
            await client.send_message(
                group_chat_id,
                alert_message,
                parse_mode='markdown',
                buttons=buttons if buttons else None
            )

            # Detailed logging
            log_entry = (
                f"[{mention_time}] Mention #{total_mentions}\n"
                f"From: {sender.first_name} (ID: {sender.id}, Username: @{getattr(sender, 'username', 'none')})\n"
                f"In: {getattr(chat, 'title', 'Private')} (ID: {chat.id})\n"
                f"Message: {event.raw_text[:200]}\n"
                f"Link: {message_link}\n\n"
            )
            with open("mentions_log.txt", "a", encoding="utf-8") as log:
                log.write(log_entry)

            logger.info(f"Processed mention #{total_mentions} from {sender.first_name}")

    except Exception as e:
        logger.error(f"Error handling mention: {str(e)}")
        try:
            await client.send_message(
                group_chat_id,
                f"⚠️ **Mention Processing Error**\n\n`{str(e)[:200]}`...",
                parse_mode='markdown'
            )
        except:
            pass

# Button callback handler
@client.on(events.CallbackQuery)
async def callback_handler(event):
    if event.data == b'get_stats':
        stats_message = (
            f"📊 **Bot Statistics**\n\n"
            f"• Total mentions: {total_mentions}\n"
            f"• Uptime: {round((time.time() - start_time)/3600, 2)} hours\n"
            f"• Memory usage: {round(psutil.Process().memory_info().rss / 1024 / 1024, 2)} MB\n"
            f"• Last check: {datetime.now().strftime('%H:%M:%S')}"
        )
        await event.answer(stats_message, alert=True)

# Connection manager
async def maintain_connection():
    retry_count = 0
    max_retries = 5
    retry_delay = 10

    while True:
        try:
            if not client.is_connected():
                logger.info("Connecting to Telegram...")
                await client.connect()

            await client.get_me()  # Verify connection
            retry_count = 0
            await asyncio.sleep(60)

        except Exception as e:
            retry_count += 1
            logger.error(f"Connection error (attempt {retry_count}/{max_retries}): {str(e)}")

            if retry_count >= max_retries:
                logger.error("Max retries reached. Shutting down.")
                try:
                    await client.send_message(
                        group_chat_id,
                        "🚨 Bot is shutting down due to connection issues",
                        parse_mode='markdown'
                    )
                except:
                    pass
                raise

            await asyncio.sleep(retry_delay)
            retry_delay = min(retry_delay * 2, 300)

# Main function
async def main():
    keep_alive()
    await maintain_connection()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
        try:
            asyncio.run(client.send_message(
                group_chat_id,
                "🛑 Bot stopped by admin",
                parse_mode='markdown'
            ))
        except:
            pass
    except Exception as e:
        logger.error(f"Bot crashed: {str(e)}")
        try:
            asyncio.run(client.send_message(
                group_chat_id,
                f"💥 Bot crashed: {str(e)[:200]}...",
                parse_mode='markdown'
            ))
        except:
            pass